# Static Classes in Java
