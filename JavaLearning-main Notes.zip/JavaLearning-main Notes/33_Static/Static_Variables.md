# Static Variables in Java
