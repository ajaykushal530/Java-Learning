# Static in Java - Overview
